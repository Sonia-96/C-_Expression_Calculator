//
//  cmdline.h
//  hw1
//
//  Created by Yue Sun on 1/12/23.
//

#ifndef cmdline_h
#define cmdline_h

void use_arguments(int argc, const char* argv[]);

#endif /* cmdline_h */
